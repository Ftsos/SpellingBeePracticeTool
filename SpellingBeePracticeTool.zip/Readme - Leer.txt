Abri el archivo que se llama index.html con google chrome o cualquier navegador

Para iniciar dale start
Despues das click al boton Listen y abajo te va a aparecer lo q vas dictando, si paras se para d escuchar asi q le das a Stop Listening
Next es para siguente palabra
Y Reveal Word revela la palabra para ver si la dijiste correctamente

lo de incorrect y correct puede fallar y seguramente va a fallar todo el tiempo